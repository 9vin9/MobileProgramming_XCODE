import UIKit

class NoteCell2: UITableViewCell{
    

}

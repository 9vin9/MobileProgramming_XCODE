import UIKit

class NoteCell: UITableViewCell{
    
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var descLable: UILabel!
    
}
